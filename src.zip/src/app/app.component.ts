import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Trackby';


  students:any[];

  countrydata:any[]=[
    {
      "country":"India",
      people:[
        { name: "ajit kumar"},
        { name: "samir kumar"},
        { name: "kamin kumar"},

      ]
    },
    {
      "country":"Indones",
      people:[
        { name: "ajit kumar"},
        { name: "samir kumar"},
        { name: "kamin kumar"},

      ]
    },
    {
      "country":"Malasiya",
      people:[
        { name: "ajit kumar"},
        { name: "samir kumar"},
        { name: "kamin kumar"},

      ]
    },
    {
      "country":"UK",
      people:[
        { name: "ajit kumar"},
        { name: "samir kumar"},
        { name: "kamin kumar"},

      ]
    },
  ]

  constructor(){
    this.students = [
      {
        id:1,
        name: 'sameer',
        gender:'male',
        age: 21,
        course:'BCA',
      },
      {
        id:2,
        name: 'sameer2',
        gender:'male',
        age: 23,
        course:'BCA',
      },
      {
        id:3,
        name: 'sameer kumar',
        gender:'male',
        age: 24,
        course:'BCA',
      },
      {
        id:4,
        name: 'sameer khan',
        gender:'male',
        age: 24,
        course:'BCA',
      },
    ]
  }
  getmoredata():void{
    this.students = [
      {
        id:1,
        name: 'sameer',
        gender:'male',
        age: 21,
        course:'BCA',
      },
      {
        id:2,
        name: 'sameer2',
        gender:'male',
        age: 23,
        course:'BCA',
      },
      {
        id:3,
        name: 'sameer kumar',
        gender:'male',
        age: 24,
        course:'BCA',
      },
      {
        id:4,
        name: 'sameer khan',
        gender:'male',
        age: 24,
        course:'BCA',
      },
      {
        id:5,
        name: 'sameer kumar jena',
        gender:'male',
        age: 24,
        course:'BCA',
      },
      {
        id:6,
        name: 'sameer khan last',
        gender:'male',
        age: 24,
        course:'BCA',
      },
    ];
  }
  trackbystudentid(index:number,students:any){
    return students.id;
  }

}
